import streamlit as st
import pandas as pd
import joblib



rf = joblib.load("random_forest.pkl")
scaler = joblib.load("scaler.pkl")
model_columns = joblib.load("columns.pkl")

st.title("Spaceship Titanic — Transported Predictor")

home_planet = st.selectbox("Home Planet", ["Earth", "Europa", "Mars"])
cryo_sleep = st.selectbox("CryoSleep", ["False", "True"])
cabin = st.text_input("Cabin (format Deck/Num/Side, e.g. B/12/S)", "B/0/S")
destination = st.selectbox("Destination", ["TRAPPIST-1e", "55 Cancri e", "PSO J318.5-22"])
age = st.number_input("Age", min_value=0, max_value=100, value=25)
vip = st.selectbox("VIP", ["False", "True"])
room_service = st.number_input("Room Service Spend", min_value=0, value=0)
food_court = st.number_input("Food Court Spend", min_value=0, value=0)
shopping_mall = st.number_input("Shopping Mall Spend", min_value=0, value=0)
spa = st.number_input("Spa Spend", min_value=0, value=0)
vr_deck = st.number_input("VR Deck Spend", min_value=0, value=0)

if st.button("Predict"):
    input_df = pd.DataFrame([{
        "HomePlanet": home_planet,
        "CryoSleep": cryo_sleep == "True",
        "Cabin": cabin,
        "Destination": destination,
        "Age": age,
        "VIP": vip == "True",
        "RoomService": room_service,
        "FoodCourt": food_court,
        "ShoppingMall": shopping_mall,
        "Spa": spa,
        "VRDeck": vr_deck,
    }])

    # Onehotencode as ass8
    input_df = pd.get_dummies(input_df)

    # Align to the exact training columns (fills missing dummy cols with 0)
    input_df = input_df.reindex(columns=model_columns, fill_value=0)

    # Scale ALL columns, since scaler was fit on the full encoded dataframe
    input_df[model_columns] = scaler.transform(input_df[model_columns])

    prediction = rf.predict(input_df)[0]

    
    if prediction == 1:
        st.success("Transported")
    else:
        st.error("Not Transported")

    prob = rf.predict_proba(input_df)[0]

    st.metric(
        "Transport Probability",
        f"{prob[1]*100:.2f}%"
    )
